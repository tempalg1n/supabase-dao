# Supabase DAO


> Скрипт реализации data access object для базы данных под управлением supabase-py



## Как использовать

- распаковать локально
- создать venv или подключить существующий
- `pip install -r requirements.txt`
- для инфы по cli `python main -h`
